# MuraScope

Cloudflare Worker + D1. Run from this folder after `npm i -g wrangler` and `wrangler login`.

1. `wrangler d1 create murascope` — paste the returned `database_id` into `wrangler.toml`.
2. `wrangler d1 execute murascope --remote --file=schema.sql`
3. `wrangler deploy` (or connect this GitHub repo in Cloudflare → Workers & Pages for auto-deploys).
4. Open your site, register, then make yourself admin:
   `wrangler d1 execute murascope --remote --command "UPDATE users SET role='admin' WHERE email='you@example.com'"`
5. Visit `/admin.html`. Submit `https://YOURDOMAIN/sitemap.xml` in Google Search Console.

Not included yet: photo uploads (add R2), email verification, password reset, anonymous reviews (accounts required), owner-claim flow (owners use "Report / request correction").
